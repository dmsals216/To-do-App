package com.project.eunmin.todoapp.datamodel

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "todo")
data class TodoDataModel(@PrimaryKey(autoGenerate = true) var id: Long?, var content: String, var date: Long, var done: Boolean)
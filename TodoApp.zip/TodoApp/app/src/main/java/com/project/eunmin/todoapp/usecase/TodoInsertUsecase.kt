package com.project.eunmin.todoapp.usecase

import com.project.eunmin.todoapp.entitygateway.TodoEntityGateway

interface TodoInsertUsecase {
    fun insert(content: String, date: Long, done: Boolean)
}

class TodoInsertUsecaseImpl(private val gateway: TodoEntityGateway): TodoInsertUsecase {
    override fun insert(content: String, date: Long, done: Boolean) = gateway.insert(content, date, done)
}
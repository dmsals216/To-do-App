package com.project.eunmin.todoapp.entity

data class TodoEntity (val id: Long, val content: String, val date: Long, val done: Boolean)
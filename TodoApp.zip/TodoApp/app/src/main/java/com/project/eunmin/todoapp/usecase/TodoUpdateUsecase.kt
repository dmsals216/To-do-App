package com.project.eunmin.todoapp.usecase

import com.project.eunmin.todoapp.entity.TodoEntity
import com.project.eunmin.todoapp.entitygateway.TodoEntityGateway

interface TodoUpdateUsecase {
    fun update(todo: TodoEntity)
}

class TodoUpdateUsecaseImpl(private val gateway: TodoEntityGateway): TodoUpdateUsecase {
    override fun update(todo: TodoEntity) = gateway.update(todo)
}